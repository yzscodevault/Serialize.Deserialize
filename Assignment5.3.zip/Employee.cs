﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment5._3
{
    [Serializable]
    public class Employee
    {
        public int Eid { get; set; }
        public string EName { get; set; }
        public string Address { get; set; }
    }
}
